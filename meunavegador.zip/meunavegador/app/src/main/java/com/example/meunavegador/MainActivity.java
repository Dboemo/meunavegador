package com.example.meunavegador;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
WebView meuweb;
Button botao;
EditText edtURL;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        meuweb=(WebView) findViewById(R.id.web);
        botao=(Button) findViewById(R.id.btir) ;
        edtURL=(EditText)findViewById(R.id.edturl);
        WebSettings settings = meuweb.getSettings();
        settings.setJavaScriptEnabled(true);
        meuweb.loadUrl("https://www.iffarroupilha.edu.br");
        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                meuweb.loadUrl(edtURL.getText().toString());
            }
        });
    }
}